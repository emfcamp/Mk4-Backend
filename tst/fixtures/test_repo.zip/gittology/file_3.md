# This is the third file in your repository

Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, __This file will generate the conflict when merged with the `merge-conflict` branch__, sunt in culpa qui officia deserunt mollit anim id est laborum.
